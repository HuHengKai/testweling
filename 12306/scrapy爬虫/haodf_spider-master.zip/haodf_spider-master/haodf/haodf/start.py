from scrapy import cmdline

cmdline.execute("scrapy crawl haodf_spider".split())