# p2pdata_analyze
分析北京互联网金融协会公布的12万条逾期数据

get_data_p2p_data.ipython 文件是爬虫代码

ppData.csv 是12万条逾期数据

p2p_data_analyze.ipyhton 是数据分析代码

good luck!!
